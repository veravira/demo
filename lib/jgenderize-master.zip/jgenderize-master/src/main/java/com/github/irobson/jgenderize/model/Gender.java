package com.github.irobson.jgenderize.model;

import java.io.Serializable;

public enum Gender implements Serializable {
    MALE, FEMALE, NULL;
}
